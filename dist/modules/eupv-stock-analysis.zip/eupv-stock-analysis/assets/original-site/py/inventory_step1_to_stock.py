from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import date, datetime, timedelta

# Default: start = today, end = today + 6 months (used only if no explicit dates passed)

def _default_start():
    return date.today()

def _default_end():
    today = date.today()
    # add 6 months
    m = today.month + 6
    y = today.year + (m - 1) // 12
    m = ((m - 1) % 12) + 1
    return date(y, m, today.day)
from pathlib import Path
from typing import Any

from openpyxl import load_workbook
from openpyxl.styles import PatternFill


OUTPUT_SHEET_NAME = "stock"
SKU_SHEET_CANDIDATES = ["SKU", "SKU Mapping", "Legacy Mapping Product"]
TRANSIT_START_DATE = None  # resolved dynamically via _default_start()
TRANSIT_END_DATE = None    # resolved dynamically via _default_end()
ALLOC_SHEET_NAME = "To be allocated"
TRANSIT_SOURCE_SHEET_NAME = "_Transit Source Map"
DOMESTIC_DETAIL_SHEET_NAME = "Domestic Stock"

SOURCE_INV_DSP = "INV_DSP"
SOURCE_ODP = "ODP"
SOURCE_MIXED = "MIXED"
UNMATCHED_SKU_MARK = "SKU not matched"
DOMESTIC_WH = "CN"

CELL_FILL_BY_SOURCE = {
    SOURCE_INV_DSP: PatternFill(fill_type="solid", fgColor="DDEBFF"),
    SOURCE_ODP: PatternFill(fill_type="solid", fgColor="FFE8CC"),
    SOURCE_MIXED: PatternFill(fill_type="solid", fgColor="EBDCFF"),
}

WH_CODE_MAP = {
    "SPNL": "NL",
    "SPFR": "FR",
    "SPTN": "FR",
    "SPUK": "UK",
    "SPIT": "IT",
    "SPES": "ES",
}


def normalize_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def normalize_lower(value: Any) -> str:
    return normalize_text(value).lower()


def normalize_sku_key(value: Any) -> str:
    return normalize_text(value).upper()


def safe_float(value: Any) -> float:
    if value in (None, ""):
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    text = normalize_text(value).replace(",", "")
    if not text:
        return 0.0
    try:
        return float(text)
    except ValueError:
        return 0.0


def build_header_index(headers: list[Any]) -> dict[str, int]:
    out: dict[str, int] = {}
    for idx, header in enumerate(headers):
        key = normalize_lower(header)
        if key and key not in out:
            out[key] = idx
    return out


def map_country_code(sales_org_name: str) -> str:
    name = normalize_lower(sales_org_name)
    if "netherland" in name or "netherlands" in name:
        return "NL"
    if "france" in name:
        return "FR"
    if "united kingdom" in name or name == "uk" or name.endswith(" uk"):
        return "UK"
    if "italy" in name:
        return "IT"
    if "spain" in name:
        return "ES"
    return normalize_text(sales_org_name)[:2].upper()


def resolve_output_category(source_category: Any, family: Any) -> str:
    category_text = normalize_upper_category(source_category)

    # Keep category from source tables when valid
    if category_text in {"PV", "ESS", "HP"}:
        return category_text

    # For rows whose category needs to be inferred from SKU-side info
    family_text = normalize_lower(family)
    if family_text in {"reserve", "non-pv", "ess - gen2"}:
        return "ESS"

    return "PV"


def normalize_upper_category(value: Any) -> str:
    text = normalize_text(value).upper()
    normalized = text.replace("_", "-").replace(" ", "")

    # Exact/normalized category recognition only, avoid false-positive from strings like NON-PV
    if normalized in {"HP", "HEATPUMP", "HEATPUMPS"}:
        return "HP"
    if normalized in {"ESS", "ESSGEN2", "ESS-GEN2"}:
        return "ESS"
    if normalized == "PV":
        return "PV"

    return text


def map_transit_wh_code(in_transit_code: Any) -> str | None:
    text = normalize_text(in_transit_code).upper()
    if not text:
        return None

    for code, wh in WH_CODE_MAP.items():
        if code in text:
            return wh
    return None


def excluded_row(brand: Any, sales_org_name: Any, virtual_warehouse_name: Any) -> bool:
    if normalize_lower(brand) == "other":
        return True

    sales_org = normalize_lower(sales_org_name)
    sales_org_compact = " ".join(sales_org.split())
    if (
        sales_org_compact == "china"
        or "business planning departmen" in sales_org_compact
        or "business planning department" in sales_org_compact
    ):
        return True

    if "arrival plan" in normalize_lower(virtual_warehouse_name):
        return True

    return False


def pick_sku_sheet_name(workbook_sheet_names: list[str], explicit_name: str | None) -> str:
    if explicit_name:
        if explicit_name in workbook_sheet_names:
            return explicit_name
        raise ValueError(f"SKU sheet not found: {explicit_name}")

    lowered = {name.lower(): name for name in workbook_sheet_names}
    for candidate in SKU_SHEET_CANDIDATES:
        if candidate.lower() in lowered:
            return lowered[candidate.lower()]
    return workbook_sheet_names[0]


def iter_dates(start_date: date, end_date: date) -> list[date]:
    days: list[date] = []
    d = start_date
    while d <= end_date:
        days.append(d)
        d += timedelta(days=1)
    return days


def date_header(d: date) -> str:
    return f"{d.year}.{d.month}.{d.day}"


def parse_supply_date(value: Any) -> date | None:
    if value in (None, ""):
        return None

    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value

    text = normalize_text(value)
    if not text:
        return None

    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue

    text = text.replace(".", "-").replace("/", "-")
    parts = text.split("-")
    if len(parts) >= 3 and all(p.isdigit() for p in parts[:3]):
        return date(int(parts[0]), int(parts[1]), int(parts[2]))

    return None


def merge_transit_payload(
    base_qty: dict[tuple[str, str, str], float],
    base_category: dict[tuple[str, str], str],
    add_qty: dict[tuple[str, str, str], float],
    add_category: dict[tuple[str, str], str],
) -> None:
    for key, qty in add_qty.items():
        base_qty[key] += qty
    for key, category in add_category.items():
        if key not in base_category and category:
            base_category[key] = category


def normalize_source_tag(value: str) -> str:
    text = normalize_text(value).upper()
    if text == SOURCE_ODP:
        return SOURCE_ODP
    if text == SOURCE_MIXED:
        return SOURCE_MIXED
    return SOURCE_INV_DSP


def merge_source_tag(curr: str, incoming: str) -> str:
    if not incoming:
        return normalize_source_tag(curr) if curr else ""
    if not curr:
        return normalize_source_tag(incoming)

    curr_norm = normalize_source_tag(curr)
    incoming_norm = normalize_source_tag(incoming)
    if curr_norm == incoming_norm:
        return curr_norm
    return SOURCE_MIXED


def extract_inventory_rows(inventory_path: Path, stock_mode: str = "available") -> list[dict[str, Any]]:
    wb = load_workbook(inventory_path, data_only=True, read_only=True)
    ws = wb[wb.sheetnames[0]]

    headers = [cell.value for cell in ws[1]]
    idx = build_header_index(headers)

    required = [
        "customer model",
        "category",
        "actual stock" if stock_mode == "total" else "available stock",
        "sales organization name",
        "virtual warehouse name",
        "brand",
    ]
    missing = [h for h in required if h not in idx]
    if missing:
        wb.close()
        raise ValueError(f"Inventory Detail missing columns: {missing}")

    stock_column = "actual stock" if stock_mode == "total" else "available stock"
    grouped: dict[tuple[str, str, str], float] = defaultdict(float)
    for row in ws.iter_rows(min_row=2, values_only=True):
        brand = row[idx["brand"]]
        sales_org_name = row[idx["sales organization name"]]
        virtual_warehouse_name = row[idx["virtual warehouse name"]]
        if excluded_row(brand, sales_org_name, virtual_warehouse_name):
            continue

        sku = normalize_text(row[idx["customer model"]])
        category = normalize_text(row[idx["category"]])
        sales_org = normalize_text(sales_org_name)
        if not sku:
            continue

        stock = safe_float(row[idx[stock_column]])
        grouped[(sku, category, sales_org)] += stock

    wb.close()

    out: list[dict[str, Any]] = []
    for (sku, category, sales_org), stock in sorted(grouped.items()):
        out.append(
            {
                "SKU": sku,
                "Category": category,
                "Stock": round(stock, 3),
                "WH": map_country_code(sales_org),
            }
        )
    return out


def build_sku_lookup(stock_wb_path: Path, sku_sheet_name: str) -> dict[str, dict[str, Any]]:
    wb = load_workbook(stock_wb_path, data_only=True)
    ws = wb[sku_sheet_name]
    headers = [cell.value for cell in ws[1]]
    idx = build_header_index(headers)

    required = [
        "sku no",
        "product model",
        "category",
        "brand",
        "level2",
        "level3",
        "billable watts(w)",
        "connector",
        "total pcs per 40hq container",
    ]
    missing = [h for h in required if h not in idx]
    if missing:
        wb.close()
        raise ValueError(f"SKU sheet missing columns: {missing}")

    lookup: dict[str, dict[str, Any]] = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        sku_key = normalize_sku_key(row[idx["sku no"]])
        if not sku_key or sku_key in lookup:
            continue
        lookup[sku_key] = {
            "Category": normalize_text(row[idx["category"]]),
            "Brand": normalize_text(row[idx["brand"]]),
            "Product TCL Report": normalize_text(row[idx["level2"]]),
            "Family": normalize_text(row[idx["level3"]]),
            "Model": normalize_text(row[idx["product model"]]),
            "Connector": normalize_text(row[idx["connector"]]),
            "Bin": safe_float(row[idx["billable watts(w)"]]),
            "MOQ": safe_float(row[idx["total pcs per 40hq container"]]),
        }

    wb.close()
    return lookup


def extract_transit_data(
    daily_supply_plan_path: Path,
    start_date: date,
    end_date: date,
    stock_mode: str = "available",
) -> tuple[dict[tuple[str, str, str], float], dict[tuple[str, str], str]]:
    wb = load_workbook(daily_supply_plan_path, data_only=True, read_only=True)
    ws = wb[wb.sheetnames[0]]

    headers = [cell.value for cell in ws[1]]
    idx = build_header_index(headers)
    quantity_column = "scheduled quantity" if stock_mode == "total" else "available quantity"
    required = ["in-transit warehouse(code)", "customer model", "supply date", quantity_column]
    missing = [h for h in required if h not in idx]
    if missing:
        wb.close()
        raise ValueError(f"DailySupplyPlan missing columns: {missing}")

    transit_qty: dict[tuple[str, str, str], float] = defaultdict(float)
    transit_category: dict[tuple[str, str], str] = {}

    has_category = "category" in idx

    for row in ws.iter_rows(min_row=2, values_only=True):
        sku = normalize_text(row[idx["customer model"]])
        if not sku:
            continue

        wh = map_transit_wh_code(row[idx["in-transit warehouse(code)"]])
        if not wh:
            continue

        supply_date = parse_supply_date(row[idx["supply date"]])
        if supply_date is None or supply_date < start_date or supply_date > end_date:
            continue

        qty = safe_float(row[idx[quantity_column]])
        d_header = date_header(supply_date)
        transit_qty[(sku, wh, d_header)] += qty

        if has_category:
            category_val = normalize_text(row[idx["category"]])
            if category_val and (sku, wh) not in transit_category:
                transit_category[(sku, wh)] = category_val

    wb.close()
    return transit_qty, transit_category


def extract_odp_transit_data(
    odp_master_path: Path,
    start_date: date,
    end_date: date,
) -> tuple[dict[tuple[str, str, str], float], dict[tuple[str, str], str], dict[str, float], list[dict[str, Any]]]:
    wb = load_workbook(odp_master_path, data_only=True, read_only=True)

    sheet_name = None
    for candidate in ("Total Stcok", "Total Stock"):
        if candidate in wb.sheetnames:
            sheet_name = candidate
            break
    if sheet_name is None:
        wb.close()
        raise ValueError("ODP file missing `Total Stcok`/`Total Stock` sheet")

    ws = wb[sheet_name]
    headers = [cell.value for cell in ws[1]]
    idx = build_header_index(headers)

    required = ["tcl reference", "new ark wh", "new ark sku", "model", "quantity", "mw", "eta for new ark update"]
    missing = [h for h in required if h not in idx]
    if missing:
        wb.close()
        raise ValueError(f"ODP Total Stock missing columns: {missing}")

    transit_qty: dict[tuple[str, str, str], float] = defaultdict(float)
    transit_category: dict[tuple[str, str], str] = {}
    domestic_qty: dict[str, float] = defaultdict(float)
    domestic_detail_map: dict[tuple[str, str, str], dict[str, Any]] = {}

    factory_lookup: dict[str, str] = {}
    for source_sheet in wb.worksheets:
        source_header_values = next(source_sheet.iter_rows(min_row=1, max_row=1, values_only=True), ())
        if not source_header_values:
            continue
        source_idx = build_header_index(list(source_header_values))
        reference_column = "tcl reference" if "tcl reference" in source_idx else (
            "tcl reference no." if "tcl reference no." in source_idx else None
        )
        if reference_column is None or "factory location" not in source_idx:
            continue
        for source_row in source_sheet.iter_rows(min_row=2, values_only=True):
            reference = normalize_text(source_row[source_idx[reference_column]])
            factory = normalize_text(source_row[source_idx["factory location"]])
            if reference and factory and reference not in factory_lookup:
                factory_lookup[reference] = factory

    has_product_type = "product type" in idx

    for row in ws.iter_rows(min_row=2, values_only=True):
        sku = normalize_text(row[idx["new ark sku"]])
        if not sku:
            continue

        raw_wh = row[idx["new ark wh"]]
        wh = map_transit_wh_code(raw_wh)
        is_arrival_plan_warehouse = "arrival plan" in normalize_lower(raw_wh) and bool(wh)
        qty = safe_float(row[idx["quantity"]])
        if not is_arrival_plan_warehouse:
            domestic_qty[sku] += qty
            reference = normalize_text(row[idx["tcl reference"]])
            model = normalize_text(row[idx["model"]])
            factory = factory_lookup.get(reference, "")
            detail_key = (sku, model, factory)
            detail = domestic_detail_map.setdefault(
                detail_key,
                {"SKU": sku, "Model": model, "Factory": factory, "Quantity": 0.0, "MW": 0.0},
            )
            detail["Quantity"] += qty
            detail["MW"] += safe_float(row[idx["mw"]])
            continue

        raw_eta = row[idx["eta for new ark update"]]
        if normalize_lower(raw_eta) in {"", "n/a", "na", "none", "null"}:
            continue
        eta_date = parse_supply_date(raw_eta)
        if eta_date is None or eta_date.year <= 1900:
            continue
        if eta_date < start_date or eta_date > end_date:
            continue

        d_header = date_header(eta_date)
        transit_qty[(sku, wh, d_header)] += qty

        if has_product_type:
            category_val = normalize_text(row[idx["product type"]])
            if category_val and (sku, wh) not in transit_category:
                transit_category[(sku, wh)] = category_val

    wb.close()
    domestic_details = [
        {
            **item,
            "Quantity": round(safe_float(item["Quantity"]), 3),
            "MW": round(safe_float(item["MW"]), 6),
        }
        for _, item in sorted(domestic_detail_map.items())
    ]
    return transit_qty, transit_category, domestic_qty, domestic_details


def extract_to_be_allocated_orders(
    order_file_path: Path,
) -> tuple[list[dict[str, Any]], dict[tuple[str, str], float]]:
    wb = load_workbook(order_file_path, data_only=True, read_only=False)
    ws = wb[wb.sheetnames[0]]

    header_row = 2
    headers = [ws.cell(header_row, c).value for c in range(1, ws.max_column + 1)]
    idx = build_header_index(headers)

    required = [
        "allocation status",
        "material",
        "ordered qty",
        "crd",
        "customer level 6 name",
        "so no.",
        "so line",
        "model",
        "factory",
    ]
    missing = [h for h in required if h not in idx]
    if missing:
        wb.close()
        raise ValueError(f"Order file missing columns: {missing}")

    orders: list[dict[str, Any]] = []
    agg_by_sku_wh: dict[tuple[str, str], float] = defaultdict(float)

    max_row = ws.max_row
    for r in range(header_row + 1, max_row + 1):
        status = normalize_lower(ws.cell(r, idx["allocation status"] + 1).value)
        if status != "to be allocated":
            continue

        sku = normalize_text(ws.cell(r, idx["material"] + 1).value)
        qty = safe_float(ws.cell(r, idx["ordered qty"] + 1).value)
        crd = ws.cell(r, idx["crd"] + 1).value
        customer_name = ws.cell(r, idx["customer level 6 name"] + 1).value
        so_no = ws.cell(r, idx["so no."] + 1).value
        so_line = ws.cell(r, idx["so line"] + 1).value
        model = ws.cell(r, idx["model"] + 1).value
        factory = ws.cell(r, idx["factory"] + 1).value
        wh = map_transit_wh_code(factory) or ""

        orders.append(
            {
                "SKU": sku,
                "Ordered Qty": round(qty, 3),
                "CRD": crd,
                "Customer Name": customer_name,
                "SO No.": so_no,
                "SO Line": so_line,
                "Model": model,
                "Factory": factory,
                "WH": wh,
            }
        )

        if sku and wh:
            agg_by_sku_wh[(sku, wh)] += qty

    wb.close()
    return orders, agg_by_sku_wh


def write_output_sheet(
    stock_wb_path: Path,
    rows: list[dict[str, Any]],
    sku_lookup: dict[str, dict[str, Any]],
    transit_qty: dict[tuple[str, str, str], float] | None = None,
    transit_category: dict[tuple[str, str], str] | None = None,
    transit_source_tag: dict[tuple[str, str, str], str] | None = None,
    daily_transit_qty: dict[tuple[str, str, str], float] | None = None,
    odp_transit_qty: dict[tuple[str, str, str], float] | None = None,
    domestic_qty: dict[str, float] | None = None,
    domestic_details: list[dict[str, Any]] | None = None,
    allocated_orders: list[dict[str, Any]] | None = None,
    allocated_need: dict[tuple[str, str], float] | None = None,
    start_date: date = None,
    end_date: date = None,
) -> dict[str, Any]:
    if start_date is None:
        start_date = _default_start()
    if end_date is None:
        end_date = _default_end()
    wb = load_workbook(stock_wb_path)

    if OUTPUT_SHEET_NAME in wb.sheetnames:
        ws_old = wb[OUTPUT_SHEET_NAME]
        wb.remove(ws_old)
    if ALLOC_SHEET_NAME in wb.sheetnames:
        alloc_old = wb[ALLOC_SHEET_NAME]
        wb.remove(alloc_old)
    if TRANSIT_SOURCE_SHEET_NAME in wb.sheetnames:
        source_old = wb[TRANSIT_SOURCE_SHEET_NAME]
        wb.remove(source_old)
    if DOMESTIC_DETAIL_SHEET_NAME in wb.sheetnames:
        domestic_old = wb[DOMESTIC_DETAIL_SHEET_NAME]
        wb.remove(domestic_old)
    ws = wb.create_sheet(OUTPUT_SHEET_NAME)

    base_headers = [
        "WH",
        "Category",
        "Brand",
        "Product TCL Report",
        "Family",
        "SKU",
        "Model",
        "Connector",
        "Bin",
        "MOQ",
        "To be allocated",
        "Total QTY",
        "Total MW",
        "MW",
        "Stock",
        "Domestic Stock",
    ]
    transit_dates = iter_dates(start_date, end_date)
    transit_headers = [date_header(d) for d in transit_dates]
    headers = base_headers + transit_headers
    ws.append(headers)

    marked_rows_info: list[dict[str, str]] = []

    def resolve_sku_mapping(sku: str) -> tuple[dict[str, Any], bool]:
        mapped = sku_lookup.get(normalize_sku_key(sku))
        if mapped:
            return mapped, False
        return {
            "Category": UNMATCHED_SKU_MARK,
            "Brand": UNMATCHED_SKU_MARK,
            "Product TCL Report": UNMATCHED_SKU_MARK,
            "Family": UNMATCHED_SKU_MARK,
            "Model": UNMATCHED_SKU_MARK,
            "Connector": UNMATCHED_SKU_MARK,
            "Bin": 0,
            "MOQ": 0,
        }, True

    def append_stock_row(
        wh: str,
        sku: str,
        mapped: dict[str, Any],
        stock: float,
        domestic_stock: float = 0,
    ) -> None:
        ws.append(
            [
                wh,
                mapped.get("Category"),
                mapped.get("Brand"),
                mapped.get("Product TCL Report"),
                mapped.get("Family"),
                sku,
                mapped.get("Model"),
                mapped.get("Connector"),
                mapped.get("Bin"),
                mapped.get("MOQ"),
                0,
                0,
                0,
                0,
                stock,
                domestic_stock,
            ]
            + [None] * len(transit_headers)
        )

    transit_qty = transit_qty or {}
    transit_category = transit_category or {}
    transit_source_tag = transit_source_tag or {}
    daily_transit_qty = daily_transit_qty or {}
    odp_transit_qty = odp_transit_qty or {}
    domestic_qty = domestic_qty or {}
    domestic_details = domestic_details or []
    allocated_orders = allocated_orders or []
    allocated_need = allocated_need or {}

    active_sku_keys: set[str] = set()
    for item in rows:
        if safe_float(item.get("Stock")) != 0:
            active_sku_keys.add(normalize_sku_key(item.get("SKU")))
    for (sku, _wh, _d_header), qty in transit_qty.items():
        if safe_float(qty) != 0:
            active_sku_keys.add(normalize_sku_key(sku))
    for (sku, _wh), qty in allocated_need.items():
        if safe_float(qty) != 0:
            active_sku_keys.add(normalize_sku_key(sku))
    for sku, qty in domestic_qty.items():
        if safe_float(qty) != 0:
            active_sku_keys.add(normalize_sku_key(sku))

    for item in rows:
        if normalize_sku_key(item["SKU"]) not in active_sku_keys:
            continue
        mapped, unmatched = resolve_sku_mapping(item["SKU"])
        if unmatched:
            marked_rows_info.append({"SKU": item["SKU"], "WH": item["WH"], "Reason": UNMATCHED_SKU_MARK})
        append_stock_row(item["WH"], item["SKU"], mapped, item["Stock"])

    header_col = {h: i + 1 for i, h in enumerate(headers)}
    row_by_key: dict[tuple[str, str], int] = {}
    for r in range(2, ws.max_row + 1):
        sku = normalize_text(ws.cell(r, header_col["SKU"]).value)
        wh = normalize_text(ws.cell(r, header_col["WH"]).value)
        if sku and wh and (sku, wh) not in row_by_key:
            row_by_key[(sku, wh)] = r

    for (sku, wh), need_qty in sorted(allocated_need.items()):
        if not sku or not wh or safe_float(need_qty) == 0:
            continue
        key = (sku, wh)
        if key in row_by_key:
            continue
        mapped, unmatched = resolve_sku_mapping(sku)
        if unmatched:
            marked_rows_info.append({"SKU": sku, "WH": wh, "Reason": UNMATCHED_SKU_MARK})
        append_stock_row(wh, sku, mapped, 0)
        row_by_key[key] = ws.max_row

    for sku, qty in sorted(domestic_qty.items()):
        if not sku or safe_float(qty) == 0:
            continue
        key = (sku, DOMESTIC_WH)
        if key not in row_by_key:
            mapped, unmatched = resolve_sku_mapping(sku)
            if unmatched:
                marked_rows_info.append({"SKU": sku, "WH": DOMESTIC_WH, "Reason": UNMATCHED_SKU_MARK})
            append_stock_row(DOMESTIC_WH, sku, mapped, 0, 0)
            row_by_key[key] = ws.max_row
        row_num = row_by_key[key]
        current = safe_float(ws.cell(row_num, header_col["Domestic Stock"]).value)
        ws.cell(row_num, header_col["Domestic Stock"]).value = round(current + qty, 3)

    stock_col = header_col["Stock"]
    domestic_stock_col = header_col["Domestic Stock"]
    ws.cell(1, stock_col).fill = CELL_FILL_BY_SOURCE[SOURCE_INV_DSP]
    ws.cell(1, domestic_stock_col).fill = CELL_FILL_BY_SOURCE[SOURCE_ODP]
    for r in range(2, ws.max_row + 1):
        ws.cell(r, stock_col).fill = CELL_FILL_BY_SOURCE[SOURCE_INV_DSP]
        if safe_float(ws.cell(r, domestic_stock_col).value) != 0:
            ws.cell(r, domestic_stock_col).fill = CELL_FILL_BY_SOURCE[SOURCE_ODP]

    date_source_summary: dict[str, str] = {}
    for (_, _, d_header), src in transit_source_tag.items():
        if d_header not in header_col:
            continue
        date_source_summary[d_header] = merge_source_tag(date_source_summary.get(d_header, ""), src)

    for d_header, src in date_source_summary.items():
        ws.cell(1, header_col[d_header]).fill = CELL_FILL_BY_SOURCE.get(normalize_source_tag(src), CELL_FILL_BY_SOURCE[SOURCE_INV_DSP])

    for (sku, wh, d_header), qty in transit_qty.items():
        if d_header not in header_col:
            continue
        if safe_float(qty) == 0 or normalize_sku_key(sku) not in active_sku_keys:
            continue

        key = (sku, wh)
        if key not in row_by_key:
            mapped, unmatched = resolve_sku_mapping(sku)
            if unmatched:
                marked_rows_info.append({"SKU": sku, "WH": wh, "Reason": UNMATCHED_SKU_MARK})
            append_stock_row(wh, sku, mapped, 0)
            row_by_key[key] = ws.max_row

        row_num = row_by_key[key]
        col_num = header_col[d_header]
        current = safe_float(ws.cell(row_num, col_num).value)
        ws.cell(row_num, col_num).value = round(current + qty, 3)
        source_tag = normalize_source_tag(transit_source_tag.get((sku, wh, d_header), SOURCE_INV_DSP))
        ws.cell(row_num, col_num).fill = CELL_FILL_BY_SOURCE.get(source_tag, CELL_FILL_BY_SOURCE[SOURCE_INV_DSP])

    for r in range(2, ws.max_row + 1):
        sku_val = normalize_text(ws.cell(r, header_col["SKU"]).value)
        wh_val = normalize_text(ws.cell(r, header_col["WH"]).value)
        need_qty = safe_float(allocated_need.get((sku_val, wh_val), 0))
        ws.cell(r, header_col["To be allocated"]).value = round(need_qty, 3)

        bin_qty = safe_float(ws.cell(r, header_col["Bin"]).value)
        stock_qty = safe_float(ws.cell(r, header_col["Stock"]).value)
        domestic_stock_qty = safe_float(ws.cell(r, header_col["Domestic Stock"]).value)
        category_value = normalize_text(ws.cell(r, header_col["Category"]).value).upper()
        is_pv = category_value.startswith("PV")

        transit_total = 0.0
        for d_col_name in transit_headers:
            transit_total += safe_float(ws.cell(r, header_col[d_col_name]).value)

        total_qty = stock_qty + domestic_stock_qty + transit_total
        mw = (stock_qty * bin_qty) / 1_000_000 if is_pv else None
        total_mw = (total_qty * bin_qty) / 1_000_000 if is_pv else None

        ws.cell(r, header_col["Total QTY"]).value = round(total_qty, 3)
        ws.cell(r, header_col["MW"]).value = round(mw, 3) if mw is not None else None
        ws.cell(r, header_col["Total MW"]).value = round(total_mw, 3) if total_mw is not None else None

    total_rows = ws.max_row - 1

    dedup_marked: list[dict[str, str]] = []
    seen_marked: set[tuple[str, str]] = set()
    for item in marked_rows_info:
        key = (item.get("SKU", ""), item.get("WH", ""))
        if key in seen_marked:
            continue
        seen_marked.add(key)
        dedup_marked.append(item)

    ws_alloc = wb.create_sheet(ALLOC_SHEET_NAME)
    ws_alloc.append(["SKU", "Connector", "Ordered Qty", "CRD", "Customer Name", "SO No.", "SO Line", "Model", "Factory", "WH"])
    for order in allocated_orders:
        if safe_float(order.get("Ordered Qty")) == 0:
            continue
        mapped, _ = resolve_sku_mapping(order.get("SKU", ""))
        ws_alloc.append(
            [
                order.get("SKU"),
                mapped.get("Connector"),
                order.get("Ordered Qty"),
                order.get("CRD"),
                order.get("Customer Name"),
                order.get("SO No."),
                order.get("SO Line"),
                order.get("Model"),
                order.get("Factory"),
                order.get("WH"),
            ]
        )

    ws_source = wb.create_sheet(TRANSIT_SOURCE_SHEET_NAME)
    ws_source.append(["SKU", "WH", "Date", "Source", "Daily Supply Plan Qty", "ODP Qty"])
    source_keys = set(transit_source_tag) | set(daily_transit_qty) | set(odp_transit_qty)
    for sku, wh, d_header in sorted(source_keys):
        if d_header not in header_col:
            continue
        src = transit_source_tag.get((sku, wh, d_header), SOURCE_INV_DSP)
        ws_source.append([
            sku,
            wh,
            d_header,
            normalize_source_tag(src),
            round(safe_float(daily_transit_qty.get((sku, wh, d_header), 0)), 3),
            round(safe_float(odp_transit_qty.get((sku, wh, d_header), 0)), 3),
        ])

    ws_domestic = wb.create_sheet(DOMESTIC_DETAIL_SHEET_NAME)
    ws_domestic.append(["SKU", "Model", "Factory", "Quantity", "MW"])
    for item in domestic_details:
        ws_domestic.append([
            item.get("SKU"),
            item.get("Model"),
            item.get("Factory"),
            round(safe_float(item.get("Quantity")), 3),
            round(safe_float(item.get("MW")), 6),
        ])

    wb.save(stock_wb_path)
    wb.close()

    return {
        "total_rows": total_rows,
        "marked_unmatched_sku_rows": len(dedup_marked),
        "marked_row_samples": dedup_marked[:20],
    }


def run(
    inventory_path: Path,
    stock_path: Path,
    sku_sheet_name: str | None = None,
    daily_supply_plan_path: Path | None = None,
    odp_master_path: Path | None = None,
    order_file_path: Path | None = None,
    transit_start_date: date = None,
    transit_end_date: date = None,
    stock_mode: str = "available",
) -> None:
    if transit_start_date is None:
        transit_start_date = _default_start()
    if transit_end_date is None:
        transit_end_date = _default_end()
    normalized_stock_mode = "total" if stock_mode == "total" else "available"
    inventory_rows = extract_inventory_rows(inventory_path, normalized_stock_mode)

    wb_probe = load_workbook(stock_path, read_only=True)
    resolved_sku_sheet = pick_sku_sheet_name(wb_probe.sheetnames, sku_sheet_name)
    wb_probe.close()

    sku_lookup = build_sku_lookup(stock_path, resolved_sku_sheet)

    transit_qty: dict[tuple[str, str, str], float] = defaultdict(float)
    transit_category: dict[tuple[str, str], str] = {}
    transit_source_tag: dict[tuple[str, str, str], str] = {}
    daily_transit_qty: dict[tuple[str, str, str], float] = defaultdict(float)
    odp_transit_qty: dict[tuple[str, str, str], float] = defaultdict(float)
    domestic_qty: dict[str, float] = defaultdict(float)
    domestic_details: list[dict[str, Any]] = []

    if daily_supply_plan_path:
        d_qty, d_category = extract_transit_data(
            daily_supply_plan_path,
            start_date=transit_start_date,
            end_date=transit_end_date,
            stock_mode=normalized_stock_mode,
        )
        merge_transit_payload(transit_qty, transit_category, d_qty, d_category)
        daily_transit_qty.update(d_qty)
        for key in d_qty:
            transit_source_tag[key] = merge_source_tag(transit_source_tag.get(key, ""), SOURCE_INV_DSP)

    if odp_master_path:
        o_qty, o_category, o_domestic_qty, domestic_details = extract_odp_transit_data(
            odp_master_path,
            start_date=transit_start_date,
            end_date=transit_end_date,
        )
        merge_transit_payload(transit_qty, transit_category, o_qty, o_category)
        odp_transit_qty.update(o_qty)
        domestic_qty.update(o_domestic_qty)
        for key in o_qty:
            transit_source_tag[key] = merge_source_tag(transit_source_tag.get(key, ""), SOURCE_ODP)

    allocated_orders: list[dict[str, Any]] = []
    allocated_need: dict[tuple[str, str], float] = defaultdict(float)
    if order_file_path:
        allocated_orders, allocated_need = extract_to_be_allocated_orders(order_file_path)

    run_summary = write_output_sheet(
        stock_path,
        inventory_rows,
        sku_lookup,
        transit_qty=transit_qty,
        transit_category=transit_category,
        transit_source_tag=transit_source_tag,
        daily_transit_qty=daily_transit_qty,
        odp_transit_qty=odp_transit_qty,
        domestic_qty=domestic_qty,
        domestic_details=domestic_details,
        allocated_orders=allocated_orders,
        allocated_need=allocated_need,
        start_date=transit_start_date,
        end_date=transit_end_date,
    )

    print(f"Done: wrote {stock_path} -> sheet {OUTPUT_SHEET_NAME}")
    print(f"Inventory grouped rows: {len(inventory_rows)}")
    print(f"SKU mapping sheet: {resolved_sku_sheet}")
    if daily_supply_plan_path:
        print(f"Transit source (DailySupplyPlan): {daily_supply_plan_path}")
    if odp_master_path:
        print(f"Transit source (ODP Total Stock): {odp_master_path}")
    if order_file_path:
        print(f"Order source (To be allocated): {order_file_path}")
    if daily_supply_plan_path or odp_master_path:
        print(f"Transit date columns: {date_header(transit_start_date)} ~ {date_header(transit_end_date)}")

    print(
        "Rows marked in stock sheet: "
        f"sku_unmatched={run_summary['marked_unmatched_sku_rows']}"
    )

    log_lines: list[str] = [
        f"Run time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Output workbook: {stock_path}",
        f"Output sheet: {OUTPUT_SHEET_NAME}",
        f"Inventory grouped rows: {len(inventory_rows)}",
        f"SKU mapping sheet: {resolved_sku_sheet}",
        f"Rows in stock sheet: {run_summary['total_rows']}",
        f"Rows marked (SKU unmatched): {run_summary['marked_unmatched_sku_rows']}",
    ]

    if daily_supply_plan_path:
        log_lines.append(f"Transit source (DailySupplyPlan): {daily_supply_plan_path}")
    if odp_master_path:
        log_lines.append(f"Transit source (ODP Total Stock): {odp_master_path}")
    if order_file_path:
        log_lines.append(f"Order source (To be allocated): {order_file_path}")
    if daily_supply_plan_path or odp_master_path:
        log_lines.append(f"Transit date columns: {date_header(transit_start_date)} ~ {date_header(transit_end_date)}")

    samples = run_summary.get("marked_row_samples", [])
    if samples:
        log_lines.append("Marked row samples (max 20):")
        for idx, sample in enumerate(samples, start=1):
            log_lines.append(
                f"  {idx}. SKU={sample.get('SKU', '')}, WH={sample.get('WH', '')}, Reason={sample.get('Reason', '')}"
            )
    else:
        log_lines.append("Marked row samples: none")

    log_path = stock_path.with_name(
        f"{stock_path.stem}_run_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    )
    log_path.write_text("\n".join(log_lines), encoding="utf-8")
    print(f"Run log written: {log_path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build stock sheet from Inventory Details + transit plan")
    parser.add_argument("--inventory", required=True, type=Path, help="Inventory Details path")
    parser.add_argument("--stock", required=True, type=Path, help="Stock workbook path")
    parser.add_argument("--sku-sheet", default=None, help="SKU mapping sheet name (optional)")
    parser.add_argument("--daily-supply-plan", default=None, type=Path, help="DailySupplyPlan path (optional)")
    parser.add_argument("--odp-master", default=None, type=Path, help="EUPV_ODP_MASTER path (optional)")
    parser.add_argument("--order-file", default=None, type=Path, help="Orderfile_Base_Realtime path (optional)")
    parser.add_argument("--transit-start", default=None, help="Transit start date YYYY-MM-DD (default: today)")
    parser.add_argument("--transit-end", default=None, help="Transit end date YYYY-MM-DD (default: today + 6 months)")
    parser.add_argument("--stock-mode", choices=("available", "total"), default="available", help="Stock calculation mode")
    return parser.parse_args()


def _parse_cli_date(text: str) -> date:
    try:
        return datetime.strptime(text.strip(), "%Y-%m-%d").date()
    except ValueError as exc:
        raise ValueError(f"Invalid date: {text}, expected YYYY-MM-DD") from exc


if __name__ == "__main__":
    args = parse_args()
    run(
        inventory_path=args.inventory,
        stock_path=args.stock,
        sku_sheet_name=args.sku_sheet,
        daily_supply_plan_path=args.daily_supply_plan,
        odp_master_path=args.odp_master,
        order_file_path=args.order_file,
        transit_start_date=_parse_cli_date(args.transit_start) if args.transit_start else None,
        transit_end_date=_parse_cli_date(args.transit_end) if args.transit_end else None,
        stock_mode=args.stock_mode,
    )
